import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useAccount, useConnect, useDisconnect } from 'wagmi';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { FcGoogle } from "react-icons/fc";
import { SiApple } from "react-icons/si";

export function ConnectButton() {
  const [showDialog, setShowDialog] = useState(false);
  const { address, isConnected } = useAccount();
  const { disconnect } = useDisconnect();
  const { connect, connectors } = useConnect();
  const { toast } = useToast();

  const handleWalletConnect = async () => {
    try {
      // Try MetaMask first, then WalletConnect
      const connector = connectors.find(c => c.ready) || connectors[0];
      if (connector) {
        await connect({ connector });
        setShowDialog(false);
        toast({
          title: "Success",
          description: "Wallet connected successfully",
        });
      } else {
        toast({
          title: "No Wallet Found",
          description: "Please install MetaMask or use WalletConnect",
          variant: "destructive",
        });
      }
    } catch (error: unknown) {
      toast({
        title: "Connection Failed",
        description: error instanceof Error ? error.message : "Failed to connect wallet",
        variant: "destructive",
      });
    }
  };

  const handleSocialLogin = async (provider: string) => {
    try {
      // Implement OAuth flow for Google/Apple
      const authUrl = `/api/auth/${provider.toLowerCase()}`;
      const response = await fetch(authUrl, { 
        method: 'POST',
        credentials: 'include'
      });
      
      if (!response.ok) throw new Error('Authentication failed');
      
      setShowDialog(false);
      toast({
        title: "Success",
        description: `Logged in with ${provider}`,
      });
    } catch (error) {
      toast({
        title: "Login Failed",
        description: `Could not login with ${provider}`,
        variant: "destructive",
      });
    }
  };

  if (isConnected) {
    return (
      <Button
        variant="outline"
        onClick={() => disconnect()}
      >
        {address?.slice(0, 6)}...{address?.slice(-4)}
      </Button>
    );
  }

  return (
    <Dialog open={showDialog} onOpenChange={setShowDialog}>
      <DialogTrigger asChild>
        <Button>Connect Wallet</Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Connect to continue</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <Button onClick={handleWalletConnect} className="w-full">
            Connect Crypto Wallet
          </Button>
          <Button onClick={() => handleSocialLogin('Google')} variant="outline" className="w-full">
            <FcGoogle className="mr-2 h-5 w-5" />
            Continue with Google
          </Button>
          <Button onClick={() => handleSocialLogin('Apple')} variant="outline" className="w-full">
            <SiApple className="mr-2 h-5 w-5" />
            Continue with Apple
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}