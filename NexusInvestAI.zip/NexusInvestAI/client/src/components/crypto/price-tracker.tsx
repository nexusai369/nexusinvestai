
import { useState, useEffect } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

export function PriceTracker() {
  const [prices, setPrices] = useState<any[]>([]);

  useEffect(() => {
    const fetchPrices = async () => {
      const response = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,binancecoin&vs_currencies=usd&include_24hr_change=true');
      const data = await response.json();
      const formattedPrices = Object.entries(data).map(([id, data]: [string, any]) => ({
        id,
        price: data.usd,
        change: data.usd_24h_change
      }));
      setPrices(formattedPrices);
    };

    fetchPrices();
    const interval = setInterval(fetchPrices, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <Card className="bg-gradient-to-br from-blue-900/80 to-indigo-900/80 backdrop-blur-lg border-blue-400/30">
      <CardHeader>
        <CardTitle>Live Crypto Prices</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {prices.map((coin) => (
            <div key={coin.id} className="flex justify-between items-center">
              <span className="capitalize">{coin.id}</span>
              <div className="text-right">
                <div>${coin.price.toLocaleString()}</div>
                <div className={coin.change > 0 ? "text-green-500" : "text-red-500"}>
                  {coin.change.toFixed(2)}%
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
