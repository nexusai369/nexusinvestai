
import { motion } from "framer-motion";

export function Logo() {
  return (
    <div className="text-center space-y-2">
      <motion.div
        className="text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-blue-500"
        initial={{ scale: 0.9 }}
        animate={{ scale: 1 }}
        transition={{ duration: 2, repeat: Infinity, repeatType: "reverse" }}
      >
        NEXUS AI
      </motion.div>
      <motion.div
        className="text-sm text-muted-foreground"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
      >
        by ZentiumVerse - The Gateway to Prosperity
      </motion.div>
    </div>
  );
}
