import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { REFERRAL_REWARDS } from "@/lib/constants";
import { useQuery } from "@tanstack/react-query";
import type { UserResponse } from "@shared/types/api";

export function ReferralCard() {
  const { toast } = useToast();

  const { data: user } = useQuery<UserResponse>({
    queryKey: ['/api/users/current'],
    retry: false,
  });

  const copyReferralLink = () => {
    const referralCode = user?.referralCode || generateReferralCode();
    navigator.clipboard.writeText(`https://nexusai.app/ref/${referralCode}`);
    toast({
      title: "Copied!",
      description: "Referral link copied to clipboard",
    });
  };

  const generateReferralCode = () => {
    return "NEXUS" + Math.random().toString(36).slice(2, 8).toUpperCase();
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Referral Program</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="p-2 bg-muted rounded-lg">
              <p className="text-xl font-bold">{REFERRAL_REWARDS.LEVEL_1}%</p>
              <p className="text-xs text-muted-foreground">Level 1</p>
            </div>
            <div className="p-2 bg-muted rounded-lg">
              <p className="text-xl font-bold">{REFERRAL_REWARDS.LEVEL_2}%</p>
              <p className="text-xs text-muted-foreground">Level 2</p>
            </div>
            <div className="p-2 bg-muted rounded-lg">
              <p className="text-xl font-bold">{REFERRAL_REWARDS.LEVEL_3}%</p>
              <p className="text-xs text-muted-foreground">Level 3</p>
            </div>
          </div>
          <div>
            <p className="text-sm text-muted-foreground mb-2">Your Referral Code</p>
            <code className="block p-2 bg-muted rounded text-center mb-2">
              {user?.referralCode || generateReferralCode()}
            </code>
            <div className="space-y-2">
            <Button 
              variant="outline" 
              className="w-full"
              onClick={copyReferralLink}
            >
              Copy Referral Link
            </Button>
            <div className="grid grid-cols-2 gap-2">
              <Button
                variant="outline"
                className="w-full"
                onClick={() => window.open(`https://wa.me/?text=Join%20Nexus%20AI%20using%20my%20referral%20link:%20https://nexusai.app/ref/${user?.referralCode}`)}
              >
                Share on WhatsApp
              </Button>
              <Button
                variant="outline"
                className="w-full"
                onClick={() => window.open(`https://twitter.com/intent/tweet?text=Join%20Nexus%20AI%20using%20my%20referral%20link:%20https://nexusai.app/ref/${user?.referralCode}`)}
              >
                Share on Twitter
              </Button>
            </div>
          </div>
          </div>
          <div className="text-sm text-muted-foreground">
            <p>• Earn {REFERRAL_REWARDS.LEVEL_1}% from direct referrals</p>
            <p>• {REFERRAL_REWARDS.LEVEL_2}% from their referrals</p>
            <p>• {REFERRAL_REWARDS.LEVEL_3}% from third level</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}