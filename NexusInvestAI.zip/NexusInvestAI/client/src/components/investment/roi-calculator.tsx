
import { useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export function ROICalculator() {
  const [investment, setInvestment] = useState("");
  const [duration, setDuration] = useState("");
  const [completedPools, setCompletedPools] = useState("");
  const [roi, setRoi] = useState<number | null>(null);
  
  const calculateROI = () => {
    const amount = parseFloat(investment);
    const months = parseFloat(duration);
    const pools = parseFloat(completedPools);
    const monthlyRate = 0.03; // 3% monthly
    const poolBonus = pools * 0.01; // 1% increase per pool
    const projectedValue = amount * Math.pow(1 + monthlyRate + poolBonus, months);
    const profitUsdt = projectedValue - amount;
    setRoi(profitUsdt);
  };

  return (
    <Card className="bg-gradient-to-br from-blue-500/10 to-purple-500/10 border-blue-300/20">
      <CardHeader>
        <CardTitle className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-400">
          ROI Calculator
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Input
          type="number"
          value={investment}
          onChange={(e) => setInvestment(e.target.value)}
          placeholder="Investment Amount"
          className="bg-white/10 border-blue-300/20"
        />
        <Input
          type="number"
          value={duration}
          onChange={(e) => setDuration(e.target.value)}
          placeholder="Duration (months)"
          className="bg-white/10 border-blue-300/20"
        />
        <Input
          type="number"
          value={completedPools}
          onChange={(e) => setCompletedPools(e.target.value)}
          placeholder="Completed Pools"
          className="bg-white/10 border-blue-300/20"
        />
        <Button 
          onClick={calculateROI} 
          className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
        >
          Calculate ROI
        </Button>
        {roi !== null && (
          <div className="text-center p-4 rounded-lg bg-white/10">
            <p className="text-lg font-semibold">Projected Profit</p>
            <p className="text-2xl font-bold text-green-400">${roi.toFixed(2)} USDT</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
