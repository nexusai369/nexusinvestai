import { useQuery } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { ZENTIUM_POOL_SIZE } from "@/lib/constants";

export function PoolStatus() {
  const { data: pool } = useQuery({
    queryKey: ["/api/pools/current"],
  });

  const { data: stats } = useQuery({
    queryKey: ["/api/stats/investors"],
  });

  const currentPrice = pool?.price ? parseFloat(pool.price) : 0;
  const progress = ((stats?.count || 0) / ZENTIUM_POOL_SIZE) * 100;

  return (
    <Card className="bg-gradient-to-br from-purple-900/80 to-pink-900/80 backdrop-blur-lg border-purple-400/30">
      <CardHeader>
        <CardTitle>Pool Status</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4">
          <div className="space-y-2">
            <p className="text-sm font-medium">Current Price</p>
            <p className="text-2xl font-bold">{currentPrice.toFixed(0)} Units</p>
          </div>
          <div className="space-y-2">
            <p className="text-sm font-medium">Pool Members</p>
            <Progress value={progress} className="mt-2" />
            <p className="text-sm text-muted-foreground mt-1">
              {stats?.count || 0} / {ZENTIUM_POOL_SIZE} members
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}