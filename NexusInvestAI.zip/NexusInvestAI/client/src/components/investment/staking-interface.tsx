import { useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { ZENTIUM_INITIAL_INVESTMENT, MONTHLY_STAKING_APR } from "@/lib/constants";

export function StakingInterface() {
  const [amount, setAmount] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const stakeMutation = useMutation({
    mutationFn: async (amount: string) => {
      return apiRequest("POST", "/api/stakes", { 
        amount: parseFloat(amount),
        userId: 1 // TODO: Get from actual user context
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users/1/stakes'] });
      toast({
        title: "Success",
        description: "Successfully staked Zentium",
      });
      setAmount("");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const monthlyReward = (parseFloat(amount) * MONTHLY_STAKING_APR / 100) || 0;
  const insufficientAmount = parseFloat(amount) < ZENTIUM_INITIAL_INVESTMENT;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Stake Zentium</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <label className="text-sm">Amount to Stake (Min. {ZENTIUM_INITIAL_INVESTMENT.toLocaleString()} Zentium)</label>
            <Input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Enter amount"
            />
            {insufficientAmount && amount && (
              <p className="text-sm text-destructive mt-1">
                Minimum stake amount is {ZENTIUM_INITIAL_INVESTMENT.toLocaleString()} Zentium
              </p>
            )}
          </div>
          <div className="p-4 bg-muted rounded-lg">
            <p className="text-sm text-muted-foreground">Monthly Reward ({MONTHLY_STAKING_APR}%)</p>
            <p className="text-xl font-bold">{monthlyReward.toLocaleString()} Zentium</p>
          </div>
          <Button 
            className="w-full"
            onClick={() => stakeMutation.mutate(amount)}
            disabled={!amount || stakeMutation.isPending || insufficientAmount}
          >
            {stakeMutation.isPending ? "Staking..." : "Stake Now"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}