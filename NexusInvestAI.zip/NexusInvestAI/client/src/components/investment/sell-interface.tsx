import { useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { UserInvestments, CurrentPoolResponse } from "@shared/types/api";

export function SellInterface() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [amount, setAmount] = useState("");
  const [address, setAddress] = useState(''); // Added state for address

  const { data: userInvestments } = useQuery<UserInvestments[]>({
    queryKey: ['/api/users/current/investments'],
    retry: false,
  });

  const { data: currentPool } = useQuery<CurrentPoolResponse>({
    queryKey: ['/api/pools/current'],
    retry: false,
  });

  const sellableMutation = useMutation({
    mutationFn: async (investmentId: number) => {
      return apiRequest("POST", `/api/investments/${investmentId}/enable-sell`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users/current/investments'] });
      toast({
        title: "Success",
        description: "Sell option enabled for your investment",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const withdrawMutation = useMutation({
    mutationFn: async (data: { amount: number, currency: string, address: string, userId: number, status: string }) => {
      return apiRequest("POST", "/api/withdrawals", data);
    },
    onSuccess: () => {
      toast({
        title: "Withdrawal Initiated",
        description: "Your withdrawal request has been submitted",
      });
      setAmount("");
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const sellableInvestments = userInvestments?.filter(inv => 
    !inv.sellEnabled && 
    inv.poolId === (currentPool?.id || 0) - 1 && 
    currentPool?.status === 'active'
  ) || [];

  return (
    <Card>
      <CardHeader>
        <CardTitle>Sell & Withdraw</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {sellableInvestments.map(investment => (
            <div key={investment.id} className="p-4 border rounded-lg">
              <p className="text-sm mb-2">Investment: {investment.amount} Zentium</p>
              <Button
                onClick={() => sellableMutation.mutate(investment.id)}
                disabled={sellableMutation.isPending}
                variant="outline"
                className="w-full"
              >
                Enable 50% Sell Option
              </Button>
            </div>
          ))}

          <div className="mt-6">
            <h3 className="text-lg font-semibold mb-4">Withdraw Earnings</h3>
            <div className="space-y-4">
              <div>
                <label className="text-sm">Amount</label>
                <Input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="Enter amount"
                />
                {/* Added Input for address */}
                <label className="text-sm mt-2">Address</label>
                <Input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Enter withdrawal address"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <Button
                  onClick={() => withdrawMutation.mutate({
                    amount: parseFloat(amount),
                    currency: 'USDT',
                    address: address || '0x...',
                    userId: 1,
                    status: 'pending'
                  })}
                  disabled={!amount || withdrawMutation.isPending}
                  variant="outline"
                >
                  Withdraw USDT
                </Button>
                <Button
                  onClick={() => withdrawMutation.mutate({
                    amount: parseFloat(amount),
                    currency: 'TRX',
                    address: address || 'T...',
                    userId: 1,
                    status: 'pending'
                  })}
                  disabled={!amount || withdrawMutation.isPending}
                  variant="outline"
                >
                  Withdraw TRX
                </Button>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}