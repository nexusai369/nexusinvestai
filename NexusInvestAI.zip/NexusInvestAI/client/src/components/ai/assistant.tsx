
import { useState } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export function AIAssistant() {
  const [query, setQuery] = useState('');
  const { toast } = useToast();

  const assistantMutation = useMutation({
    mutationFn: async (question: string) => {
      return apiRequest("POST", "/api/ai/assistant", { question });
    },
    onSuccess: (data) => {
      toast({
        title: "AI Response",
        description: data.response,
      });
    },
  });

  return (
    <div className="fixed bottom-4 right-4 w-72">
      <Card className="bg-gradient-to-r from-blue-500/10 to-purple-500/10">
        <CardContent className="p-4">
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Ask me anything..."
            className="mb-2"
          />
          <Button
            onClick={() => assistantMutation.mutate(query)}
            disabled={!query || assistantMutation.isPending}
            className="w-full bg-gradient-to-r from-blue-500 to-purple-500"
          >
            Ask AI
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
