
import { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export function KYCVerification() {
  const [document, setDocument] = useState<File | null>(null);
  const { toast } = useToast();

  const kycMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('documentImage', file);
      return apiRequest("POST", "/api/users/current/kyc", formData);
    },
    onSuccess: () => {
      toast({
        title: "KYC Submitted",
        description: "Your verification is being processed",
      });
    },
  });

  return (
    <Card className="relative transform hover:scale-105 transition-all duration-300 shadow-xl bg-gradient-to-r from-blue-500/10 to-purple-500/10">
      <div className="absolute -right-4 -top-4 w-24 h-24">
        <div className="rotating-cube"></div>
      </div>
      <CardHeader>
        <CardTitle className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-500 to-purple-500">
          KYC Verification
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Input
          type="file"
          onChange={(e) => setDocument(e.target.files?.[0] || null)}
          accept="image/*"
          className="mb-4"
        />
        <Button 
          onClick={() => document && kycMutation.mutate(document)}
          disabled={!document || kycMutation.isPending}
          className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
        >
          Submit Verification
        </Button>
      </CardContent>
    </Card>
  );
}
