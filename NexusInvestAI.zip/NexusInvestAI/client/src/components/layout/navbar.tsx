
import { Link } from "wouter";
import { ConnectButton } from "../wallet/connect-button";

export function Navbar() {
  return (
    <nav className="border-b">
      <div className="flex h-16 items-center px-4 container mx-auto">
        <div className="mr-4 hidden md:flex">
          <Link href="/">
            <span className="text-xl font-bold cursor-pointer">Nexus AI</span>
          </Link>
        </div>
        <div className="flex items-center space-x-4 flex-1 justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/dashboard">
              <span className="text-sm font-medium cursor-pointer">Dashboard</span>
            </Link>
            <Link href="/dex">
              <span className="text-sm font-medium cursor-pointer">DEX</span>
            </Link>
          </div>
          <ConnectButton />
        </div>
      </div>
    </nav>
  );
}
