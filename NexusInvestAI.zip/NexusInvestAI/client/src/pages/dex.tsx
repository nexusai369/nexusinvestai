import { useState } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { ZENTIUM_TOKEN_ADDRESS } from "@/lib/constants";

export default function DEX() {
  const [amount, setAmount] = useState("");
  const [token, setToken] = useState("USDT");
  const { toast } = useToast();

  const swapMutation = useMutation({
    mutationFn: async ({ amount, token }: { amount: string; token: string }) => {
      return apiRequest("POST", "/api/swap", { amount, token });
    },
    onSuccess: () => {
      toast({
        title: "Swap Initiated",
        description: `Successfully swapped ${amount} Zentium to ${token}`,
      });
      setAmount("");
    },
    onError: (error) => {
      toast({
        title: "Swap Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const handleSwap = () => {
    swapMutation.mutate({ amount, token });
  };

  // Mock exchange rates
  const rates = {
    USDT: 1,
    TRX: 15,
    BNB: 0.003
  };

  const estimatedOutput = parseFloat(amount) * rates[token as keyof typeof rates] || 0;

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Decentralized Exchange</h1>
      <div className="max-w-md mx-auto">
        <Card>
          <CardHeader>
            <CardTitle>Swap Zentium</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <label className="text-sm">From (Zentium)</label>
                <Input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="Enter Zentium amount"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Token: {ZENTIUM_TOKEN_ADDRESS}
                </p>
              </div>
              <div>
                <label className="text-sm">To</label>
                <Select value={token} onValueChange={setToken}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="USDT">USDT</SelectItem>
                    <SelectItem value="TRX">TRX</SelectItem>
                    <SelectItem value="BNB">BNB</SelectItem>
                  </SelectContent>
                </Select>
                {amount && (
                  <p className="text-sm text-muted-foreground mt-2">
                    Estimated output: {estimatedOutput.toFixed(6)} {token}
                  </p>
                )}
              </div>
              <Button 
                className="w-full" 
                onClick={handleSwap}
                disabled={!amount || swapMutation.isPending}
              >
                {swapMutation.isPending ? "Swapping..." : "Swap"}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}