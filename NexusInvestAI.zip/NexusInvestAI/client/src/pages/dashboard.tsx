
import { motion } from 'framer-motion';
import { Canvas } from '@react-three/fiber';
import { Stars, OrbitControls } from '@react-three/drei';
import { Logo } from "@/components/ui/logo";
import { PriceTracker } from "@/components/crypto/price-tracker";
import { PoolStatus } from "@/components/investment/pool-status";
import { StakingInterface } from "@/components/investment/staking-interface";
import { ReferralCard } from "@/components/referral/referral-card";
import { SellInterface } from "@/components/investment/sell-interface";
import { ROICalculator } from "@/components/investment/roi-calculator";

function Background() {
  return (
    <div className="fixed inset-0 -z-10 bg-gradient-to-b from-background to-background/80" />
  );
}

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#030014] via-[#0a0a2e] to-[#0f0f35] text-white relative overflow-hidden">
      <Background />
      <div className="container mx-auto px-4 py-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Logo />
        </motion.div>
        <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {[
            <PriceTracker key="price" />,
            <PoolStatus key="pool" />,
            <StakingInterface key="staking" />,
            <ReferralCard key="referral" />,
            <SellInterface key="sell" />,
            <ROICalculator key="roi" />
          ].map((component, i) => (
            <motion.div
              key={i}
              className="glass-morphism"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3, delay: i * 0.1 }}
            >
              {component}
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
