// API Response Types
export interface UserResponse {
  id: number;
  address: string;
  referralCode: string;
  isKYCVerified: boolean;
  kycVerificationDate: string | null;
}

export interface InvestorStats {
  count: number;
  referralCode?: string;
}

export interface CurrentPoolResponse {
  id: number;
  currentMembers: number;
  price: number;
  status: 'active' | 'full';
  createdAt: string;
  completedAt: string | null;
}

export interface UserInvestments {
  id: number;
  userId: number;
  poolId: number;
  amount: string;
  investedAt: string;
  sellEnabled: boolean;
  sellAmount: string | null;
  sellRequestedAt: string | null;
}