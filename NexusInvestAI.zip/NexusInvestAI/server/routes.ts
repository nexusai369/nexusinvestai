import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertStakeSchema, insertInvestmentSchema, insertWithdrawalSchema } from "@shared/schema";
import { verifyKYCDocument } from "./ai/kyc-verification";

export async function registerRoutes(app: Express): Promise<Server> {
  // User routes
  app.post("/api/users", async (req, res) => {
    const result = insertUserSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    const user = await storage.createUser(result.data);
    res.json(user);
  });

  app.get("/api/users/:address", async (req, res) => {
    const user = await storage.getUserByAddress(req.params.address);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    res.json(user);
  });

  // KYC routes
  app.post("/api/users/:userId/kyc", async (req, res) => {
    const { documentImage } = req.body;
    const userId = Number(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ error: "Invalid user ID" });
    }
    const result = await verifyKYCDocument(userId, documentImage);
    res.json(result);
  });

  // Stake routes
  app.post("/api/stakes", async (req, res) => {
    const result = insertStakeSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    const stake = await storage.createStake(result.data);
    res.json(stake);
  });

  app.get("/api/users/:userId/stakes", async (req, res) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ error: "Invalid user ID" });
    }
    const stakes = await storage.getStakesByUser(userId);
    res.json(stakes);
  });

  // Investment routes
  app.post("/api/investments", async (req, res) => {
    const result = insertInvestmentSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    const investment = await storage.createInvestment(result.data);
    res.json(investment);
  });

  app.get("/api/users/:userId/investments", async (req, res) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ error: "Invalid user ID" });
    }
    const investments = await storage.getInvestmentsByUser(userId);
    res.json(investments);
  });

  // Pool routes
  app.get("/api/pools/current", async (_req, res) => {
    const pool = await storage.getCurrentPool();
    res.json(pool);
  });

  app.post("/api/investments/:id/enable-sell", async (req, res) => {
    const investment = await storage.enableInvestmentSell(parseInt(req.params.id));
    res.json(investment);
  });

  // Withdrawal routes
  app.post("/api/withdrawals", async (req, res) => {
    try {
      const result = insertWithdrawalSchema.safeParse({
        ...req.body,
        status: 'pending'
      });
      
      if (!result.success) {
        return res.status(400).json({ error: result.error.format() });
      }

      if (!result.data.amount || result.data.amount <= 0) {
        return res.status(400).json({ error: "Invalid withdrawal amount" });
      }

      if (!result.data.address) {
        return res.status(400).json({ error: "Withdrawal address is required" });
      }

      const withdrawal = await storage.createWithdrawal(result.data);
      res.json(withdrawal);
    } catch (error) {
      console.error('Withdrawal error:', error);
      res.status(500).json({ error: "Failed to process withdrawal" });
    }
  });

  app.get("/api/users/:userId/withdrawals", async (req, res) => {
    const userId = parseInt(req.params.userId);
    if (isNaN(userId)) {
      return res.status(400).json({ error: "Invalid user ID" });
    }
    const withdrawals = await storage.getWithdrawalsByUser(userId);
    res.json(withdrawals);
  });

  app.get("/api/stats/investors", async (_req, res) => {
    const count = await storage.getTotalInvestors();
    res.json({ count });
  });

  const httpServer = createServer(app);
  return httpServer;
}