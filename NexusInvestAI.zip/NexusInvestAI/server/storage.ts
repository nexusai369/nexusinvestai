import { 
  users, stakes, investments, withdrawals, pools,
  type User, type InsertUser,
  type Stake, type InsertStake,
  type Investment, type InsertInvestment,
  type Withdrawal, type InsertWithdrawal,
  type Pool, type InsertPool
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, sql } from "drizzle-orm";
import { ZENTIUM_POOL_SIZE } from "@/lib/constants";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByAddress(address: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserKYCStatus(userId: number, status: boolean): Promise<User>;

  // Stake operations
  createStake(stake: InsertStake): Promise<Stake>;
  getStakesByUser(userId: number): Promise<Stake[]>;
  processStakingRewards(userId: number): Promise<void>;

  // Investment operations
  createInvestment(investment: InsertInvestment): Promise<Investment>;
  getInvestmentsByUser(userId: number): Promise<Investment[]>;
  getTotalInvestors(): Promise<number>;
  enableInvestmentSell(investmentId: number): Promise<Investment>;

  // Pool operations
  getCurrentPool(): Promise<Pool>;
  createPool(pool: InsertPool): Promise<Pool>;
  updatePoolMembers(poolId: number): Promise<Pool>;

  // Withdrawal operations
  createWithdrawal(withdrawal: InsertWithdrawal): Promise<Withdrawal>;
  getWithdrawalsByUser(userId: number): Promise<Withdrawal[]>;
  processWithdrawal(withdrawalId: number): Promise<Withdrawal>;

  // Referral operations
  getReferralEarnings(userId: number): Promise<number>;
  getReferralCount(userId: number): Promise<{ level1: number; level2: number; level3: number; }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByAddress(address: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.address, address));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUserKYCStatus(userId: number, status: boolean): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ 
        isKYCVerified: status,
        kycVerificationDate: status ? new Date() : null
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  // Stake operations
  async createStake(insertStake: InsertStake): Promise<Stake> {
    const now = new Date();
    const lockPeriodEnd = new Date(now.setDate(now.getDate() + 90)); // 90-day lock period

    const [stake] = await db
      .insert(stakes)
      .values({
        ...insertStake,
        stakedAt: new Date(),
        lastRewardAt: new Date(),
        lockPeriodEnd,
        totalRewards: "0"
      })
      .returning();

    return stake;
  }

  async getStakesByUser(userId: number): Promise<Stake[]> {
    return db.select().from(stakes).where(eq(stakes.userId, userId));
  }

  async processStakingRewards(userId: number): Promise<void> {
    const userStakes = await this.getStakesByUser(userId);
    const now = new Date();

    for (const stake of userStakes) {
      const monthsSinceLastReward = (now.getTime() - stake.lastRewardAt.getTime()) / (30 * 24 * 60 * 60 * 1000);
      if (monthsSinceLastReward >= 1) {
        const monthlyReward = Number(stake.amount) * 0.03; // 3% monthly
        await db
          .update(stakes)
          .set({
            totalRewards: sql`${stakes.totalRewards} + ${monthlyReward}`,
            lastRewardAt: now
          })
          .where(eq(stakes.id, stake.id));
      }
    }
  }

  // Investment operations
  async createInvestment(insertInvestment: InsertInvestment): Promise<Investment> {
    const [investment] = await db
      .insert(investments)
      .values({
        ...insertInvestment,
        investedAt: new Date(),
        sellEnabled: false,
        sellAmount: null,
        sellRequestedAt: null
      })
      .returning();

    // Update pool members count
    await this.updatePoolMembers(insertInvestment.poolId);

    return investment;
  }

  async getInvestmentsByUser(userId: number): Promise<Investment[]> {
    return db.select().from(investments).where(eq(investments.userId, userId));
  }

  async getTotalInvestors(): Promise<number> {
    try {
      const [result] = await db
        .select({ 
          count: sql<number>`CAST(COUNT(DISTINCT ${investments.userId}) AS INTEGER)` 
        })
        .from(investments);
      return result?.count || 0;
    } catch (error) {
      console.error('Error getting total investors:', error);
      return 0;
    }
  }

  async enableInvestmentSell(investmentId: number): Promise<Investment> {
    const [investment] = await db
      .update(investments)
      .set({
        sellEnabled: true,
        sellAmount: sql`${investments.amount} / 2`, // 50% of investment
        sellRequestedAt: new Date()
      })
      .where(eq(investments.id, investmentId))
      .returning();
    return investment;
  }

  // Pool operations
  async getCurrentPool(): Promise<Pool> {
    const [pool] = await db
      .select()
      .from(pools)
      .where(eq(pools.status, 'active'))
      .orderBy(desc(pools.id))
      .limit(1);
    return pool;
  }

  async createPool(insertPool: InsertPool): Promise<Pool> {
    const [pool] = await db
      .insert(pools)
      .values({
        ...insertPool,
        currentMembers: 0,
        status: 'active',
        createdAt: new Date(),
        completedAt: null
      })
      .returning();
    return pool;
  }

  async updatePoolMembers(poolId: number): Promise<Pool> {
    // Count members in the pool
    const [{ count }] = await db
      .select({ count: sql<number>`count(*)` })
      .from(investments)
      .where(eq(investments.poolId, poolId));

    const isFull = count >= ZENTIUM_POOL_SIZE;

    // Update current pool
    const [pool] = await db
      .update(pools)
      .set({
        currentMembers: count,
        status: isFull ? 'full' : 'active',
        completedAt: isFull ? new Date() : null
      })
      .where(eq(pools.id, poolId))
      .returning();

    // If pool is full, create new pool with incremented price
    if (isFull && pool) {
      const currentPrice = parseFloat(pool.price) || 1;
      const nextPrice = (currentPrice + 1).toString();

      await this.createPool({
        price: nextPrice,
        status: 'active'
      });
    }

    return pool;
  }

  // Withdrawal operations
  async createWithdrawal(insertWithdrawal: InsertWithdrawal): Promise<Withdrawal> {
    const [withdrawal] = await db
      .insert(withdrawals)
      .values({
        ...insertWithdrawal,
        status: 'pending',
        createdAt: new Date(),
        processedAt: null
      })
      .returning();
    return withdrawal;
  }

  async getWithdrawalsByUser(userId: number): Promise<Withdrawal[]> {
    return db.select().from(withdrawals).where(eq(withdrawals.userId, userId));
  }

  async processWithdrawal(withdrawalId: number): Promise<Withdrawal> {
    const [withdrawal] = await db
      .update(withdrawals)
      .set({
        status: 'completed',
        processedAt: new Date()
      })
      .where(eq(withdrawals.id, withdrawalId))
      .returning();
    return withdrawal;
  }

  // Referral operations
  async getReferralEarnings(userId: number): Promise<number> {
    const directReferrals = await this.getReferralsByLevel(userId, 1);
    const level2Referrals = await this.getReferralsByLevel(userId, 2);
    const level3Referrals = await this.getReferralsByLevel(userId, 3);

    const directEarnings = directReferrals.reduce((sum, inv) => sum + Number(inv.amount) * 0.09, 0);
    const level2Earnings = level2Referrals.reduce((sum, inv) => sum + Number(inv.amount) * 0.06, 0);
    const level3Earnings = level3Referrals.reduce((sum, inv) => sum + Number(inv.amount) * 0.03, 0);

    return directEarnings + level2Earnings + level3Earnings;
  }

  private async getReferralsByLevel(userId: number, level: number): Promise<Investment[]> {
    if (level === 1) {
      return db
        .select()
        .from(investments)
        .innerJoin(users, eq(investments.userId, users.id))
        .where(eq(users.referrerId, userId));
    }

    const referralIds = await this.getReferralUserIds(userId, level);
    return db
      .select()
      .from(investments)
      .where(sql`${investments.userId} = any(${referralIds})`);
  }

  private async getReferralUserIds(userId: number, level: number): Promise<number[]> {
    if (level <= 1) return [];

    const query = `
      WITH RECURSIVE referral_chain AS (
        SELECT id, referrer_id, 1 as level
        FROM users
        WHERE referrer_id = $1

        UNION ALL

        SELECT u.id, u.referrer_id, rc.level + 1
        FROM users u
        INNER JOIN referral_chain rc ON u.referrer_id = rc.id
        WHERE rc.level < $2
      )
      SELECT id FROM referral_chain WHERE level = $2;
    `;

    const result = await db.execute(sql.raw(query, [userId, level]));
    return result.rows.map(row => row.id);
  }

  async getReferralCount(userId: number): Promise<{ level1: number; level2: number; level3: number; }> {
    const level1 = await db
      .select({ count: sql<number>`count(*)` })
      .from(users)
      .where(eq(users.referrerId, userId));

    const level2Ids = await this.getReferralUserIds(userId, 2);
    const level3Ids = await this.getReferralUserIds(userId, 3);

    return {
      level1: level1[0]?.count || 0,
      level2: level2Ids.length,
      level3: level3Ids.length
    };
  }
}

export const storage = new DatabaseStorage();