import OpenAI from "openai";
import { storage } from "../storage";

const openai = new OpenAI();

interface KYCVerificationResult {
  isValid: boolean;
  confidence: number;
  message: string;
}

export async function verifyKYCDocument(
  userId: number,
  documentImage: string
): Promise<KYCVerificationResult> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o", 
      messages: [
        {
          role: "system",
          content: "You are a KYC verification expert. Analyze the provided document and verify its authenticity.",
        },
        {
          role: "user",
          content: [
            { type: "text", text: "Please verify this identity document:" },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${documentImage}`,
              },
            },
          ],
        },
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");

    if (result.isValid) {
      await storage.updateUserKYCStatus(userId, true);
    }

    return {
      isValid: result.isValid || false,
      confidence: result.confidence || 0,
      message: result.message || "Error processing KYC document",
    };
  } catch (error) {
    console.error("KYC verification error:", error);
    return {
      isValid: false,
      confidence: 0,
      message: "Error processing KYC document",
    };
  }
}