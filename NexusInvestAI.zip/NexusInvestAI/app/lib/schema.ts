import { pgTable, text, serial, numeric, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Users table with Web3 and OAuth support
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  address: text("address").unique(), // Web3 wallet address
  email: text("email").unique(), // For Google/Apple login
  authProvider: text("auth_provider"), // 'wallet', 'google', 'apple'
  referralCode: text("referral_code").notNull().unique(),
  referrerId: integer("referrer_id").references(() => users.id),
  isKYCVerified: boolean("is_kyc_verified").default(false),
  kycVerificationDate: timestamp("kyc_verification_date"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// User relations
export const usersRelations = relations(users, ({ many, one }) => ({
  referrals: many(users, { relationName: "referral" }),
  referrer: one(users, {
    fields: [users.referrerId],
    references: [users.id],
    relationName: "referral"
  }),
  stakes: many(stakes),
  investments: many(investments),
  withdrawals: many(withdrawals),
}));

// Investment pools (369 members per pool)
export const pools = pgTable("pools", {
  id: serial("id").primaryKey(),
  currentMembers: integer("current_members").notNull().default(0),
  price: numeric("price").notNull(),
  status: text("status").notNull(), // 'active', 'full'
  createdAt: timestamp("created_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
});

// Pool relations
export const poolsRelations = relations(pools, ({ many }) => ({
  investments: many(investments),
}));

// Investments in pools
export const investments = pgTable("investments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  poolId: integer("pool_id").references(() => pools.id).notNull(),
  amount: numeric("amount").notNull(),
  investedAt: timestamp("invested_at").notNull().defaultNow(),
  sellEnabled: boolean("sell_enabled").default(false),
  sellAmount: numeric("sell_amount"),
  sellRequestedAt: timestamp("sell_requested_at"),
});

// Investment relations
export const investmentsRelations = relations(investments, ({ one }) => ({
  user: one(users, {
    fields: [investments.userId],
    references: [users.id],
  }),
  pool: one(pools, {
    fields: [investments.poolId],
    references: [pools.id],
  }),
}));

// Stakes for monthly ROI
export const stakes = pgTable("stakes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  amount: numeric("amount").notNull(),
  stakedAt: timestamp("staked_at").notNull().defaultNow(),
  lastRewardAt: timestamp("last_reward_at").notNull().defaultNow(),
  totalRewards: numeric("total_rewards").notNull().default("0"),
});

// Stakes relations
export const stakesRelations = relations(stakes, ({ one }) => ({
  user: one(users, {
    fields: [stakes.userId],
    references: [users.id],
  }),
}));

// Withdrawals (USDT/TRX)
export const withdrawals = pgTable("withdrawals", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  amount: numeric("amount").notNull(),
  currency: text("currency").notNull(), // USDT, TRX
  address: text("address").notNull(),
  status: text("status").notNull(), // pending, completed, failed
  createdAt: timestamp("created_at").notNull().defaultNow(),
  processedAt: timestamp("processed_at"),
});

// Withdrawal relations
export const withdrawalsRelations = relations(withdrawals, ({ one }) => ({
  user: one(users, {
    fields: [withdrawals.userId],
    references: [users.id],
  }),
}));

// Create insert schemas (excluding auto-generated fields)
export const insertUserSchema = createInsertSchema(users).omit({ 
  id: true, 
  createdAt: true, 
  kycVerificationDate: true 
});

export const insertPoolSchema = createInsertSchema(pools).omit({ 
  id: true, 
  createdAt: true, 
  completedAt: true,
  currentMembers: true
});

export const insertInvestmentSchema = createInsertSchema(investments).omit({ 
  id: true, 
  investedAt: true,
  sellEnabled: true,
  sellAmount: true,
  sellRequestedAt: true
});

export const insertStakeSchema = createInsertSchema(stakes).omit({ 
  id: true, 
  stakedAt: true, 
  lastRewardAt: true, 
  totalRewards: true 
});

export const insertWithdrawalSchema = createInsertSchema(withdrawals).omit({ 
  id: true, 
  createdAt: true, 
  processedAt: true 
});

// Export types
export type User = typeof users.$inferSelect;
export type Pool = typeof pools.$inferSelect;
export type Investment = typeof investments.$inferSelect;
export type Stake = typeof stakes.$inferSelect;
export type Withdrawal = typeof withdrawals.$inferSelect;

export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertPool = z.infer<typeof insertPoolSchema>;
export type InsertInvestment = z.infer<typeof insertInvestmentSchema>;
export type InsertStake = z.infer<typeof insertStakeSchema>;
export type InsertWithdrawal = z.infer<typeof insertWithdrawalSchema>;
