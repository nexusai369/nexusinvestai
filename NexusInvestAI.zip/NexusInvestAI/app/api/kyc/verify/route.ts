import { NextRequest, NextResponse } from 'next/server';
import OpenAI from 'openai';
import { withDb } from '@/lib/db';
import { users } from '@/lib/schema';
import { eq } from 'drizzle-orm';

const openai = new OpenAI();

export async function POST(req: NextRequest) {
  try {
    const { userId, documentImage } = await req.json();

    // Call OpenAI Vision API to verify the document
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024
      messages: [
        {
          role: "system",
          content: "You are a KYC verification expert. Analyze the provided document and verify its authenticity.",
        },
        {
          role: "user",
          content: [
            { type: "text", text: "Please verify this identity document:" },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${documentImage}`,
              },
            },
          ],
        },
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content);

    if (result.isValid) {
      // Update user's KYC status
      await withDb(async (db) => {
        await db.update(users)
          .set({ 
            isKYCVerified: true,
            kycVerificationDate: new Date()
          })
          .where(eq(users.id, userId));
      });
    }

    return NextResponse.json({
      isValid: result.isValid,
      confidence: result.confidence,
      message: result.message,
    });
  } catch (error) {
    console.error("KYC verification error:", error);
    return NextResponse.json({
      isValid: false,
      confidence: 0,
      message: "Error processing KYC document",
    }, { status: 500 });
  }
}
